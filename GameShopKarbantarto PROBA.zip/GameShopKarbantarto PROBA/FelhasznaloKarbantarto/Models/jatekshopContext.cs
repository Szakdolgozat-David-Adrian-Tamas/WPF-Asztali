﻿using System;
using System.Collections.Generic;
using FelhasznaloKarbantarto.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WPF_jatekShop.Models
{
    public partial class jatekshopContext : DbContext
    {
        public jatekshopContext()
        {
        }

        public jatekshopContext(DbContextOptions<jatekshopContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Felhasznalok> Felhasznaloks { get; set; } = null!;
        public virtual DbSet<Osszesjatek> Osszesjateks { get; set; } = null!;
        public virtual DbSet<Registry> Registries { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

                optionsBuilder.UseMySQL("server=localhost;database=jatekshop;user=root;password=;ssl mode=none;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Felhasznalok>(entity =>
            {
                entity.ToTable("felhasznalok");

                entity.HasIndex(e => e.Email, "Email")
                    .IsUnique();

                entity.HasIndex(e => e.FelhasznaloNev, "FelhasznaloNev")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Aktiv).HasColumnType("int(1)");

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.FelhasznaloNev).HasMaxLength(30);

                entity.Property(e => e.Hash)
                    .HasMaxLength(64)
                    .HasColumnName("HASH");

                entity.Property(e => e.Jogosultsag).HasColumnType("int(1)");

                entity.Property(e => e.Salt)
                    .HasMaxLength(64)
                    .HasColumnName("SALT");

                entity.Property(e => e.TeljesNev).HasMaxLength(50);
            });

            modelBuilder.Entity<Osszesjatek>(entity =>
            {
                entity.ToTable("osszesjatek");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasColumnName("id");

                entity.Property(e => e.Ar)
                    .HasColumnType("int(11)")
                    .HasColumnName("ar");

                entity.Property(e => e.Kategoria)
                    .HasMaxLength(50)
                    .HasColumnName("kategoria");

                entity.Property(e => e.Kep)
                    .HasColumnType("mediumblob")
                    .HasColumnName("kep");

                entity.Property(e => e.Leiras)
                    .HasMaxLength(255)
                    .HasColumnName("leiras");

                entity.Property(e => e.Megjelenes)
                    .HasColumnType("date")
                    .HasColumnName("megjelenes");

                entity.Property(e => e.Nev)
                    .HasMaxLength(255)
                    .HasColumnName("nev");
            });

            modelBuilder.Entity<Registry>(entity =>
            {
                entity.ToTable("registry");

                entity.HasIndex(e => e.Key, "key")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.FelhasznaloNev).HasMaxLength(30);

                entity.Property(e => e.Hash)
                    .HasMaxLength(64)
                    .HasColumnName("HASH");

                entity.Property(e => e.Key).HasMaxLength(64);

                entity.Property(e => e.Salt)
                    .HasMaxLength(64)
                    .HasColumnName("SALT");

                entity.Property(e => e.TeljesNev).HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
