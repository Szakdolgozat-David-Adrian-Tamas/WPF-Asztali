﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace FelhasznaloKarbantarto
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        void MenuPontokBekapcsolasa(MainWindow window)
        {
            if (FelhasznaloKarbantarto.MainWindow.Jogosultsag == 9)
            {
                window.FelhAdatKarb.IsEnabled = true;
            }
        }
        private void Login(object sender, StartupEventArgs e)
        {
            Login login = new Login();
            Application.Current.MainWindow = login;
            MainWindow window = new MainWindow();
            login.ShowDialog();
            if (FelhasznaloKarbantarto.MainWindow.UserName == "")
            {
                Application.Current.Shutdown();
            }
            else
            {
                MessageBox.Show("Sikeresen bejelentkezve: " + FelhasznaloKarbantarto.MainWindow.UserName);
                MenuPontokBekapcsolasa(window);
                window.Show();
            }
        }

    }
}
