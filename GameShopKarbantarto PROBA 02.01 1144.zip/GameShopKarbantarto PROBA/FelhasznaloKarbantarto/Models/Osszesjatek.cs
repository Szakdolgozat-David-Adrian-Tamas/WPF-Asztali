﻿using System;
using System.Collections.Generic;

namespace WPF_jatekShop.Models
{
    public partial class Osszesjatek
    {
        public int Id { get; set; }
        public string Nev { get; set; } = null!;
        public string Kategoria { get; set; } = null!;
        public int Ar { get; set; }
        public string Leiras { get; set; } = null!;
        public byte[] Kep { get; set; } = null!;
        public DateTime Megjelenes { get; set; }


    }
}
