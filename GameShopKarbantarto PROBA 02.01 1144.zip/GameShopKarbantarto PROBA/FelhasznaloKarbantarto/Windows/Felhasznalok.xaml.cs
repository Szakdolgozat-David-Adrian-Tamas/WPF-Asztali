﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPF_jatekShop.Models;

namespace FelhasznaloKarbantarto.Windows
{
    /// <summary>
    /// Interaction logic for Felhasznalok.xaml
    /// </summary>
    public partial class Felhasznalok : Window
    {
        bool beolvasva = false;
        int ID=0;
        string Salt = "";
        string Hash = "";

        private string Ellenorzes()
        {
            return "";
        }
        private void MezokTorlese()
        {
            ID = 0;
            txb_JatekNev.Text = "";
            txb_Kategoria.Text = "";
            txb_JatekNev.Text = "";
            txb_Kategoria.Text = "";
            txb_Ar.Text = "0";
            txb_Leiras.Text = "";
           // txb_Kep.Text = "";
            txb_Megjelenes.Text = "";
            //cmb_Jogosultsag.Text = "0";
            //cmb_Aktiv.Text = "1";
        }
        private void AdatBeolvasas()
        {
            List<Osszesjatek> list = new List<Osszesjatek>();
            Osszesjatek jatekok = new Osszesjatek();
            WebClient client = new WebClient();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = Encoding.UTF8;
            string url = $"https://localhost:5001/api/jatek";
            MezokTorlese();
            try
            {
                string result = client.DownloadString(url);
                list = JsonConvert.DeserializeObject<List<Osszesjatek>>(result);
            }
            catch (Exception ex) {
                Felhasznalok_Adatai.ItemsSource = list;
                beolvasva = true;
            }
            
        }
        public Felhasznalok()
        {
            InitializeComponent();
            if (!beolvasva)
            {
                AdatBeolvasas();
                //cmb_Jogosultsag.ItemsSource = JogLista;
                //cmb_Aktiv.ItemsSource = AktivLista;
            }
        }

        private void Felhasznalok_adatai_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                Osszesjatek jatek = Felhasznalok_Adatai.SelectedItems[0] as Osszesjatek;
                ID = jatek.Id;
                txb_JatekNev.Text = jatek.Nev;
                txb_Kategoria.Text = jatek.Kategoria;
                txb_Ar.Text = jatek.Ar.ToString();
                txb_Kategoria.Text = jatek.Kategoria;
                //txb_Kep.Text = jatek.Kep.ToString();
                txb_Megjelenes.Text = jatek.Megjelenes.ToString();
            }
            catch (Exception ex)
            {
                AdatBeolvasas();
            }
        }

        private void btn_Tarolas_Click(object sender, RoutedEventArgs e)
        {
            string uzenet = Ellenorzes();
            if (uzenet == "")
            {
                Osszesjatek jatek = new Osszesjatek();
                jatek.Nev = txb_JatekNev.Text;
                jatek.Leiras = txb_Leiras.Text;
                //felhasznalo.Salt = MainWindow.GenerateSalt();
                //felhasznalo.Hash = MainWindow.CreateSHA256(MainWindow.CreateSHA256(pwb_Password.Password + felhasznalo.Salt));
                jatek.Ar = int.Parse(txb_Ar.Text);
                jatek.Kategoria = txb_Kategoria.Text;
                WebClient client = new WebClient();
                client.Headers[HttpRequestHeader.ContentType] = "application/json";
                client.Encoding = Encoding.UTF8;
                string url = $"https://localhost:5001/jatek";
                try
                {
                    string result = client.UploadString(url, "POST", JsonConvert.SerializeObject(jatek));
                    MessageBox.Show(result);
                    AdatBeolvasas();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(uzenet);
            }
        }

        private void btn_Modositas_Click(object sender, RoutedEventArgs e)
        {
            //string uzenet = Ellenorzes();
            //if (uzenet == "")
            //{
            //    if (ID != 0)
            //    {
            //        Models.Felhasznalok felhasznalo = new Models.Felhasznalok();
            //        felhasznalo.Id = ID;
            //        felhasznalo.FelhasznaloNev = txb_FelhasznaloNev.Text;
            //        felhasznalo.TeljesNev = txb_TeljesNev.Text;
            //        if (pwb_Password.Password != "")
            //        {
            //            felhasznalo.Salt = MainWindow.GenerateSalt();
            //            felhasznalo.Hash = MainWindow.CreateSHA256(MainWindow.CreateSHA256(pwb_Password.Password + felhasznalo.Salt));
            //        }
            //        else
            //        {
            //            felhasznalo.Salt = Salt;
            //            felhasznalo.Hash = Hash;
            //        }
            //        felhasznalo.Email = txb_Email.Text;
            //        felhasznalo.Jogosultsag = int.Parse(cmb_Jogosultsag.Text);
            //        felhasznalo.Aktiv = int.Parse(cmb_Aktiv.Text);
            //        WebClient client = new WebClient();
            //        client.Headers[HttpRequestHeader.ContentType] = "application/json";
            //        client.Encoding = Encoding.UTF8;
            //        string url = $"https://localhost:5001/Felhasznalok/{FelhasznaloKarbantarto.MainWindow.uId}";
            //        try
            //        {
            //            string result = client.UploadString(url, "PUT", JsonConvert.SerializeObject(felhasznalo));
            //            MessageBox.Show(result);
            //            AdatBeolvasas();
            //        }
            //        catch (Exception ex)
            //        {
            //            MessageBox.Show(ex.Message);
            //        }
            //    }
            //}
            //else
            //{
            //    MessageBox.Show(uzenet);
            //}
        }

        private void btn_Torles_Click(object sender, RoutedEventArgs e)
        {
            //if (MessageBox.Show($"Biztosan törli a(z) {txb_TeljesNev.Text} nevű felhasználót?",
            //        "Felhasználó törlése",
            //        MessageBoxButton.YesNo,
            //        MessageBoxImage.Warning) == MessageBoxResult.Yes)
            //{
            //    Models.Felhasznalok felhasznalo = new Models.Felhasznalok();
            //    felhasznalo.Id = ID;
            //    WebClient client = new WebClient();
            //    client.Headers[HttpRequestHeader.ContentType] = "application/json";
            //    client.Encoding = Encoding.UTF8;
            //    string url = $"https://localhost:5001/Felhasznalok/{FelhasznaloKarbantarto.MainWindow.uId}?id={ID}";
            //    try
            //    {
            //        string result = client.UploadString(url, "DELETE", "");
            //        MessageBox.Show(result);
            //        AdatBeolvasas();
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.Message);
            //    }
            //}
        }
    }
}
